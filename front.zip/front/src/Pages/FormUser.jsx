import React from 'react';

const FormUser = () => {
    return <h2>Página de Formulario</h2>;
};

export default FormUser;