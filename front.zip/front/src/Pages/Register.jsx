import React from 'react';

const Register = () => {
    return <h2>Página de Registro</h2>;
};

export default Register;